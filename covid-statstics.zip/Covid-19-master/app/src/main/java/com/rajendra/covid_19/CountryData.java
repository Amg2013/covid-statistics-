package com.rajendra.covid_19;

public class CountryData {

    public  static final String[] countryNames = {

            "IND", "USA", "MY", "AFG", "MF"
    };

    public  static final int[] countryFlag = {

            R.drawable.india, R.drawable.uk, R.drawable.malesiya, R.drawable.afganistan, R.drawable.maxico
    };

}
